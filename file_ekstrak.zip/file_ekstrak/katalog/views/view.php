<div id="container-chart">
</div>

<div>
	<h3>Harga HPS</h3>
    <div class="tableWrapper">
    	<div class="tableHeader">
			<a href="<?php echo site_url('katalog/tambah_harga/'.$id);?>" class="btnBlue"><i class="fa fa-plus"></i> Tambah</a>
		</div>
		<table class="tableData">
			<thead>
				<tr>
					<td><a href="">Harga<i class="fa fa-sort-asc"></i></a></td>
					<td><a href="">Tanggal<i class="fa fa-sort-asc"></i></a></td>
					<td><a href="">Vendor<i class="fa fa-sort-asc"></i></a></td>
				</tr>
			</thead>
			<tbody>
			
					<tr>
						<td>15000</td>
						<td>17-08-2015</td>
						<td>PT Dekodr Indonesia</td>
					</tr>
					<tr>
						<td>15430</td>
						<td>17-08-2015</td>
						<td>PT Dekodr Indonesia</td>
					</tr>
					<tr>
						<td>15300</td>
						<td>17-08-2015</td>
						<td>PT. Nusantara Regas</td>
					</tr>
					<tr>
						<td>15300</td>
						<td>17-08-2015</td>
						<td>PT. Nusantara Regas</td>
					</tr>
				
			</tbody>
		</table>
		
	</div>
</div>